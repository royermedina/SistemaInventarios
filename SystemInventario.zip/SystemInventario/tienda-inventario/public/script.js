const tablaBody = document.querySelector('#tabla tbody');
const form = document.querySelector('#formProducto');
const alerta = document.querySelector('#alerta');
const inputBusqueda = document.querySelector('#busqueda');
const resumen = document.querySelector('#resumen');
const selectOrden = document.querySelector('#ordenProductos');
const selectFiltroUnidad = document.querySelector('#filtroUnidad');
const selUnidad = document.querySelector('#unidad');
const selMovProducto = document.querySelector('#movProducto');
const selFiltroProducto = document.querySelector('#filtroProducto');
const formMov = document.querySelector('#formMovimiento');
const tablaMovsBody = document.querySelector('#tablaMovs tbody');
const filtroDesde = document.querySelector('#filtroDesde');
const filtroHasta = document.querySelector('#filtroHasta');
const btnFiltrar = document.querySelector('#btnFiltrar');
// Tabs
const tabButtons = Array.from(document.querySelectorAll('.tab-btn'));
const views = Array.from(document.querySelectorAll('.view'));
let __facturasEnabled = null; // detección de soporte de /facturas en backend
function activarVista(id) {
  tabButtons.forEach(b => b.classList.toggle('active', b.dataset.tab === id));
  views.forEach(v => v.classList.toggle('active', v.dataset.view === id));
  if (id === 'resumen') actualizarKPIs();
  if (id === 'ventas') inicializarVistaVentas();
  if (id === 'resumen') cargarVentasResumen();
  if (id === 'resumen') cargarKPIsDelDia();
  if (id === 'resumen') inicializarSubtabsResumen();
}
tabButtons.forEach(b => b.addEventListener('click', () => activarVista(b.dataset.tab)));

function mostrarAlerta(texto, tipo = 'ok') {
  if (!alerta) return;
  alerta.textContent = texto;
  alerta.className = `alert ${tipo}`;
  alerta.hidden = false;
  setTimeout(() => (alerta.hidden = true), 2500);
}

function formatoMoneda(n) {
  return new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN', minimumFractionDigits: 2 }).format(Number(n || 0));
}

function calcularResumen(productos) {
  const totalItems = productos.length;
  const unidades = productos.reduce((acc, p) => acc + Number(p.cantidad || 0), 0);
  const valorInventario = productos.reduce((acc, p) => acc + (Number(p.cantidad || 0) * Number(p.precio || 0)), 0);
  
  // Estadísticas por tipo de unidad
  const productosPorUnidad = productos.filter(p => p.unidad === 'unidad').length;
  const productosPorKilos = productos.filter(p => p.unidad === 'kg').length;
  const productosPorLibras = productos.filter(p => p.unidad === 'lb').length;
  
  // Valor promedio por producto
  const valorPromedio = totalItems > 0 ? valorInventario / totalItems : 0;
  
  // Productos con stock bajo (menos de 5 unidades)
  const stockBajo = productos.filter(p => p.cantidad < 5).length;
  
  resumen.textContent = `${totalItems} productos • ${unidades} unidades • Inventario: ${formatoMoneda(valorInventario)}`;
  
  // KPIs detallados
  const kpiDisp = document.querySelector('#kpiDisponibles');
  const kpiVal = document.querySelector('#kpiValor');
  const kpiReg = document.querySelector('#kpiRegistrados');
  if (kpiDisp) kpiDisp.textContent = unidades;
  if (kpiVal) kpiVal.textContent = formatoMoneda(valorInventario);
  if (kpiReg) kpiReg.textContent = totalItems;
  
  // Agregar estadísticas adicionales si existen los elementos
  const kpiUnidad = document.querySelector('#kpiUnidad');
  const kpiKilos = document.querySelector('#kpiKilos');
  const kpiLibras = document.querySelector('#kpiLibras');
  const kpiPromedio = document.querySelector('#kpiPromedio');
  const kpiStockBajo = document.querySelector('#kpiStockBajo');
  
  if (kpiUnidad) kpiUnidad.textContent = productosPorUnidad;
  if (kpiKilos) kpiKilos.textContent = productosPorKilos;
  if (kpiLibras) kpiLibras.textContent = productosPorLibras;
  if (kpiPromedio) kpiPromedio.textContent = formatoMoneda(valorPromedio);
  if (kpiStockBajo) kpiStockBajo.textContent = stockBajo;
}

async function cargarProductos(query = '') {
  const params = new URLSearchParams();
  if (query) params.set('search', query);
  // Para compatibilidad, seguimos enviando solo la búsqueda al backend
  const url = params.toString() ? `/productos?${params.toString()}` : '/productos';
  const res = await fetch(url);
  let productos = await res.json();

  // Aplicar filtro por unidad en el frontend
  if (selectFiltroUnidad && selectFiltroUnidad.value && selectFiltroUnidad.value !== 'all') {
    const unit = selectFiltroUnidad.value;
    if (unit === 'weight') {
      productos = productos.filter(p => (p.unidad === 'kg' || p.unidad === 'lb'));
    } else {
      productos = productos.filter(p => String(p.unidad || 'unidad') === unit);
    }
  }

  // Aplicar ordenación en el frontend
  if (selectOrden && selectOrden.value) {
    const [sort, order] = selectOrden.value.split(':');
    const dir = order === 'asc' ? 1 : -1;
    if (sort === 'nombre') {
      productos = productos.slice().sort((a, b) => a.nombre.localeCompare(b.nombre, 'es', { sensitivity: 'base' }) * dir);
    } else if (sort === 'id') {
      productos = productos.slice().sort((a, b) => (a.id - b.id) * dir);
    }
  }
  tablaBody.innerHTML = productos.map((p) => {
    const total = Number(p.cantidad || 0) * Number(p.precio || 0);
    return `
      <tr>
        <td>${p.id}</td>
        <td>${p.nombre}</td>
        <td>
          <div class="qty">
            <input type="number" min="0" step="1" value="${p.cantidad}" data-id="${p.id}" class="input-cant" />
            <button class="btn small btn-inc" data-id="${p.id}" data-delta="1">+1</button>
            <button class="btn small btn-dec" data-id="${p.id}" data-delta="-1">-1</button>
          </div>
        </td>
        <td>
          <input type="number" min="0" step="0.01" value="${p.precio}" data-id="${p.id}" class="input-precio" />
        </td>
        <td>${p.unidad || 'unidad'}</td>
        <td>${formatoMoneda(total)}</td>
        <td>
          <button class="btn warn btn-guardar" data-id="${p.id}">Guardar</button>
          <button class="btn danger btn-eliminar" data-id="${p.id}">Eliminar</button>
        </td>
      </tr>
    `;
  }).join('');
  calcularResumen(productos);

  // Rellenar selects de productos
  const options = productos.map(p => `<option value="${p.id}">${p.nombre} (${p.cantidad} ${p.unidad || 'unidad'})</option>`).join('');
  if (selMovProducto) selMovProducto.innerHTML = `<option value="" disabled selected>Seleccione...</option>` + options;
  if (selFiltroProducto) selFiltroProducto.innerHTML = `<option value="">Todos</option>` + options;
  if (typeof sincronizarSelectVentas === 'function') sincronizarSelectVentas(productos);
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const datos = {
    nombre: document.querySelector('#nombre').value.trim(),
    cantidad: parseInt(document.querySelector('#cantidad').value, 10),
    precio: parseFloat(document.querySelector('#precio').value)
  };
  const resp = await fetch('/productos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...datos, unidad: selUnidad.value })
  });
  if (!resp.ok) {
    const error = await resp.json().catch(() => ({}));
    mostrarAlerta((error.errores && error.errores.join(', ')) || error.error || 'Error al agregar', 'error');
    return;
  }
  form.reset();
  mostrarAlerta('Producto agregado');
  cargarProductos(inputBusqueda.value.trim());
});

// Delegación de eventos en la tabla
document.addEventListener('click', async (e) => {
  const guardarBtn = e.target.closest('.btn-guardar');
  const eliminarBtn = e.target.closest('.btn-eliminar');
  const incBtn = e.target.closest('.btn-inc');
  const decBtn = e.target.closest('.btn-dec');

  if (guardarBtn) {
    const id = Number(guardarBtn.dataset.id);
    const cantInput = document.querySelector(`.input-cant[data-id="${id}"]`);
    const precioInput = document.querySelector(`.input-precio[data-id="${id}"]`);
    const payload = {};
    if (cantInput) payload.cantidad = parseInt(cantInput.value, 10);
    if (precioInput) payload.precio = parseFloat(precioInput.value);
    const resp = await fetch(`/productos/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      mostrarAlerta(err.error || 'Error al actualizar', 'error');
      return;
    }
    mostrarAlerta('Producto actualizado');
    cargarProductos(inputBusqueda.value.trim());
  }

  if (eliminarBtn) {
    const id = Number(eliminarBtn.dataset.id);
    if (!confirm('¿Eliminar producto?')) return;
    const resp = await fetch(`/productos/${id}`, { method: 'DELETE' });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      mostrarAlerta(err.error || 'Error al eliminar', 'error');
      return;
    }
    mostrarAlerta('Producto eliminado');
    cargarProductos(inputBusqueda.value.trim());
  }

  if (incBtn || decBtn) {
    const btn = incBtn || decBtn;
    const id = Number(btn.dataset.id);
    const delta = Number(btn.dataset.delta);
    const cantInput = document.querySelector(`.input-cant[data-id="${id}"]`);
    const nueva = Math.max(0, parseInt(cantInput.value, 10) + delta);
    cantInput.value = nueva;
  }
});

// Búsqueda en vivo
inputBusqueda.addEventListener('input', (e) => {
  const q = e.target.value.trim();
  cargarProductos(q);
});

// Reaccionar a cambios de orden y filtro
if (selectOrden) {
  selectOrden.addEventListener('change', () => cargarProductos(inputBusqueda.value.trim()));
}
if (selectFiltroUnidad) {
  selectFiltroUnidad.addEventListener('change', () => cargarProductos(inputBusqueda.value.trim()));
}

// Cargar inicial
cargarProductos();
cargarMovimientos();
activarVista('productos');

// Variables para facturación (se cargarán dinámicamente)
let buscarProductoFactura, resultadosBusqueda, productoSeleccionado, nombreProducto, precioProducto, stockProducto, cantidadFactura, btnAgregarProducto, facturaBody, facturaVacia, totalesFactura, subtotalFactura, totalFactura, numeroFactura, fechaFactura, cedulaCliente, opcionesPago, montoRecibido, cambioMonto, pagoEfectivo, btnLimpiarFactura, btnProcesarFactura, tablaVentasBody;

// Factura actual
let facturaActual = [];
let productoActual = null;
let productosDisponibles = [];

// Ventas (atajo de movimiento tipo venta)
const formVenta = document.querySelector('#formVenta');
const selVentaProducto = document.querySelector('#ventaProducto');
const ventaCantidad = document.querySelector('#ventaCantidad');
const ventaFecha = document.querySelector('#ventaFecha');
async function recargarVentasRecientes() {
  const hoy = new Date().toISOString().slice(0,10);
  const res = await fetch(`/movimientos?from=${hoy}&to=${hoy}`);
  const rows = await res.json();
  const ventas = rows.filter(r => r.tipo === 'venta');
  tablaVentasBody.innerHTML = ventas.map(v => {
    const total = (typeof v.precio_unitario === 'number') ? (v.precio_unitario * v.cantidad) : null;
    return `
    <tr>
      <td>${v.fecha}</td>
      <td>${v.nombre}</td>
      <td>${v.cantidad}</td>
      <td>${v.unidad}</td>
      <td>${total != null ? formatoMoneda(total) : '-'}</td>
    </tr>
  `;
  }).join('');
}

if (formVenta) {
  formVenta.addEventListener('submit', async (e) => {
    e.preventDefault();
    const productoId = parseInt(selVentaProducto.value, 10);
    const cantidad = parseFloat(ventaCantidad.value);
    const fecha = ventaFecha.value || undefined;
    const resp = await fetch('/movimientos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productoId, tipo: 'venta', cantidad, fecha })
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      mostrarAlerta(err.error || 'Error al registrar venta', 'error');
      return;
    }
    mostrarAlerta('Venta registrada');
    formVenta.reset();
    cargarProductos(inputBusqueda.value.trim());
    recargarVentasRecientes();
    cargarMovimientos();
    actualizarKPIs();
  });
}

function sincronizarSelectVentas(productos) {
  const options = productos.map(p => `<option value="${p.id}">${p.nombre} (${p.cantidad} ${p.unidad || 'unidad'})</option>`).join('');
  if (selVentaProducto) selVentaProducto.innerHTML = `<option value="" disabled selected>Seleccione...</option>` + options;
}

async function actualizarKPIs() {
  // Reusa la carga de productos para refrescar KPIs
  const res = await fetch('/productos');
  const productos = await res.json();
  calcularResumen(productos);
}

// Subpestañas en Resumen
function inicializarSubtabsResumen() {
  const subBtns = Array.from(document.querySelectorAll('.tab-btn.sub'));
  const subviews = Array.from(document.querySelectorAll('.subview'));
  // Estado inicial: Facturas como principal
  subviews.forEach(v => v.classList.toggle('active', v.dataset.subview === 'facturas'));
  subBtns.forEach(b => b.classList.toggle('active', b.dataset.subtab === 'facturas'));
  subBtns.forEach(b => {
    b.onclick = () => {
      subBtns.forEach(x => x.classList.toggle('active', x === b));
      subviews.forEach(v => v.classList.toggle('active', v.dataset.subview === b.dataset.subtab));
    };
  });

  // Hook para filtro de día de facturas
  const btnDia = document.querySelector('#btnFacturaDia');
  if (btnDia) {
    btnDia.onclick = () => cargarVentasResumen();
  }
}

// Cargar ventas para el resumen (facturas)
async function cargarVentasResumen() {
  const tbody = document.querySelector('#tablaVentasResumen tbody');
  if (!tbody) return;
  try {
    const hoy = new Date().toISOString().slice(0,10);
    const diaSelInput = document.querySelector('#filtroFacturaDia');
    const dia = diaSelInput && diaSelInput.value ? diaSelInput.value : hoy;
    // Si ya sabemos que no hay soporte, usar legacy /ventas
    if (__facturasEnabled === false) {
      const resV = await fetch('/ventas');
      const ventas = await resV.json();
      const ventasHoy = ventas.filter(v => String(v.fecha).slice(0,10) === dia);
      tbody.innerHTML = ventasHoy.map(v => `
        <tr>
          <td>${v.fecha}</td>
          <td>${v.nombre}</td>
          <td>${v.cantidad}</td>
          <td>${formatoMoneda(v.total)}</td>
        </tr>
      `).join('');
      return;
    }

    // Intentar con /facturas
    const res = await fetch(`/facturas?from=${dia}&to=${dia}`);
    if (res.status === 404) {
      __facturasEnabled = false;
      // Reintenta con legacy
      const resV = await fetch('/ventas');
      const ventas = await resV.json();
      const ventasHoy = ventas.filter(v => String(v.fecha).slice(0,10) === dia);
      tbody.innerHTML = ventasHoy.map(v => `
        <tr>
          <td>${v.fecha}</td>
          <td>${v.nombre}</td>
          <td>${v.cantidad}</td>
          <td>${formatoMoneda(v.total)}</td>
        </tr>
      `).join('');
      return;
    }
    const facturas = await res.json();
    // Expandir cada factura a filas de items
    const filas = [];
    for (const f of facturas) {
      const ri = await fetch(`/facturas/${f.id}/items`);
      const items = await ri.json();
      // Encabezado factura
      filas.push(`
        <tr>
          <td colspan="4" style="font-weight:700; background:#f9fafb">Factura ${f.numero} — ${f.fecha_hora} — Total: ${formatoMoneda(f.total)}</td>
        </tr>
      `);
      // Items
      items.forEach(it => {
        filas.push(`
          <tr>
            <td>${f.fecha_hora}</td>
            <td>${it.nombre}</td>
            <td>${it.cantidad}</td>
            <td>${formatoMoneda(it.total)}</td>
          </tr>
        `);
      });
    }
    tbody.innerHTML = filas.join('');
  } catch (_) {
    tbody.innerHTML = '';
  }
}

// Registrar movimiento (opcional, solo si existe formulario en el DOM)
if (formMov) {
  formMov.addEventListener('submit', async (e) => {
    e.preventDefault();
    const productoId = parseInt(selMovProducto.value, 10);
    const tipo = document.querySelector('#movTipo').value;
    const cantidad = parseFloat(document.querySelector('#movCantidad').value);
    const fecha = document.querySelector('#movFecha').value || undefined;
    const precioUnitario = parseFloat(document.querySelector('#movPrecio').value) || undefined;
    const nuevaCantidad = document.querySelector('#movNuevaCant').value ? parseInt(document.querySelector('#movNuevaCant').value, 10) : undefined;
    const resp = await fetch('/movimientos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productoId, tipo, cantidad, fecha, precioUnitario, nuevaCantidad })
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      mostrarAlerta(err.error || 'Error al registrar movimiento', 'error');
      return;
    }
    mostrarAlerta('Movimiento registrado');
    formMov.reset();
    cargarProductos(inputBusqueda.value.trim());
    cargarMovimientos();
  });
}

async function cargarMovimientos() {
  const qs = new URLSearchParams();
  if (filtroDesde.value) qs.set('from', filtroDesde.value);
  if (filtroHasta.value) qs.set('to', filtroHasta.value);
  if (selFiltroProducto.value) qs.set('productoId', selFiltroProducto.value);
  const url = qs.toString() ? `/movimientos?${qs}` : '/movimientos';
  const res = await fetch(url);
  const rows = await res.json();
  tablaMovsBody.innerHTML = rows.map(m => `
    <tr>
      <td>${m.fecha}</td>
      <td>${m.nombre}</td>
      <td>${m.tipo}</td>
      <td>${m.cantidad}</td>
      <td>${m.unidad}</td>
      <td>${m.precio_unitario != null ? formatoMoneda(m.precio_unitario) : '-'}</td>
      <td>${m.saldo}</td>
      <td>${m.nota || ''}</td>
    </tr>
  `).join('');
}

btnFiltrar.addEventListener('click', (e) => {
  e.preventDefault();
  cargarMovimientos();
});

// Inicial historia
cargarMovimientos();

// ===== FUNCIONES DE FACTURACIÓN =====

// Inicializar factura
function inicializarFactura() {
  const ahora = new Date();
  numeroFactura.textContent = generarNumeroFactura();
  fechaFactura.textContent = ahora.toLocaleString('es-PE');
  facturaActual = [];
  productoActual = null;
  actualizarFactura();
}

// Cargar productos disponibles para búsqueda
async function cargarProductosDisponibles() {
  try {
    const res = await fetch('/productos');
    productosDisponibles = await res.json();
    console.log('Productos cargados para facturación:', productosDisponibles.length);
  } catch (error) {
    console.error('Error cargando productos:', error);
    productosDisponibles = [];
  }
}


// Actualizar visualización de la factura
function actualizarFactura() {
  if (facturaActual.length === 0) {
    if (facturaVacia) facturaVacia.hidden = false;
    if (facturaBody) facturaBody.hidden = true;
    if (totalesFactura) totalesFactura.hidden = true;
    if (opcionesPago) opcionesPago.hidden = true;
    return;
  }
  
  if (facturaVacia) facturaVacia.hidden = true;
  if (facturaBody) facturaBody.hidden = false;
  if (totalesFactura) totalesFactura.hidden = false;
  if (opcionesPago) opcionesPago.hidden = false;
  
  // Renderizar productos de la factura
  if (facturaBody) {
    facturaBody.innerHTML = facturaActual.map((item, index) => `
      <div class="factura-item" data-index="${index}">
        <div class="item-info-factura">
          <div class="item-nombre-factura">${item.nombre}</div>
          <div class="item-details-factura">${formatoMoneda(item.precio)} por ${item.unidad}</div>
        </div>
        <div class="item-cantidad-factura">
          <button onclick="cambiarCantidadFactura(${index}, -1)">-</button>
          <input type="number" value="${item.cantidad}" min="1" max="${item.stockDisponible || 999}" 
                 onchange="actualizarCantidadFactura(${index}, this.value)" />
          <button onclick="cambiarCantidadFactura(${index}, 1)">+</button>
          <button class="eliminar" onclick="eliminarDeFactura(${index})" title="Eliminar">×</button>
        </div>
        <div class="item-precio-factura">${formatoMoneda(item.total)}</div>
      </div>
    `).join('');
  }
  
  // Calcular totales
  const subtotalCalculado = facturaActual.reduce((sum, item) => sum + item.total, 0);
  if (subtotalFactura) subtotalFactura.textContent = formatoMoneda(subtotalCalculado);
  if (totalFactura) totalFactura.textContent = formatoMoneda(subtotalCalculado);
  
  // Actualizar cambio si es pago en efectivo
  actualizarCambio();
}

// Eliminar producto de la factura
function eliminarDeFactura(index) {
  facturaActual.splice(index, 1);
  actualizarFactura();
}

// Cambiar cantidad de producto en la factura
function cambiarCantidadFactura(index, delta) {
  const item = facturaActual[index];
  if (!item) return;
  
  const nuevaCantidad = item.cantidad + delta;
  if (nuevaCantidad < 1) {
    eliminarDeFactura(index);
    return;
  }
  
  if (nuevaCantidad > (item.stockDisponible || 999)) {
    mostrarAlerta('No hay suficiente inventario', 'error');
    return;
  }
  
  item.cantidad = nuevaCantidad;
  item.total = item.precio * nuevaCantidad;
  actualizarFactura();
}

// Actualizar cantidad desde input
function actualizarCantidadFactura(index, nuevaCantidad) {
  const item = facturaActual[index];
  if (!item) return;
  
  const cantidad = parseInt(nuevaCantidad);
  if (isNaN(cantidad) || cantidad < 1) {
    item.cantidad = 1;
  } else if (cantidad > (item.stockDisponible || 999)) {
    item.cantidad = item.stockDisponible || 999;
    mostrarAlerta('No hay suficiente inventario', 'error');
  } else {
    item.cantidad = cantidad;
  }
  
  item.total = item.precio * item.cantidad;
  actualizarFactura();
}

// Limpiar factura completa
function limpiarFactura() {
  facturaActual = [];
  limpiarSeleccion();
  actualizarFactura();
  montoRecibido.value = '';
  actualizarCambio();
  inicializarFactura();
}

// Limpia la selección del producto actual en la vista de ventas
function limpiarSeleccion() {
  productoActual = null;
  if (productoSeleccionado) productoSeleccionado.hidden = true;
  if (buscarProductoFactura) buscarProductoFactura.value = '';
  if (cantidadFactura) cantidadFactura.value = 1;
  if (resultadosBusqueda) resultadosBusqueda.hidden = true;
}

// Actualizar cambio en pago efectivo
function actualizarCambio() {
  if (!montoRecibido || !cambioMonto) return;
  
  const monto = parseFloat(montoRecibido.value) || 0;
  const total = facturaActual.reduce((sum, item) => sum + item.total, 0);
  const cambio = monto - total;
  
  cambioMonto.textContent = formatoMoneda(Math.max(0, cambio));
  cambioMonto.style.color = cambio >= 0 ? '#16a34a' : '#dc2626';
}

// Manejar cambio de método de pago
document.addEventListener('change', (e) => {
  if (e.target.name === 'metodoPago') {
    const metodo = e.target.value;
    if (metodo === 'efectivo') {
      pagoEfectivo.hidden = false;
    } else {
      pagoEfectivo.hidden = true;
    }
  }
});

// Procesar factura
async function procesarFactura() {
  console.log('Procesando factura...', facturaActual);
  
  if (facturaActual.length === 0) {
    mostrarAlerta('La factura está vacía', 'error');
    return;
  }
  
  const metodoPago = document.querySelector('input[name="metodoPago"]:checked').value;
  const total = facturaActual.reduce((sum, item) => sum + item.total, 0);
  
  if (metodoPago === 'efectivo') {
    const monto = parseFloat(montoRecibido.value) || 0;
    if (monto < total) {
      mostrarAlerta('El monto recibido es insuficiente', 'error');
      return;
    }
  }
  
  try {
    // Construir payload de factura
    const payload = {
      clienteCedula: cedulaCliente.value.trim() || null,
      metodoPago,
      items: facturaActual.map(it => ({
        productoId: it.id,
        cantidad: it.cantidad,
        precioUnitario: it.precio
      }))
    };
    let res = { ok: false, status: 404 };
    if (__facturasEnabled !== false) {
      try {
        res = await fetch('/facturas', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (_) {
        // si falla la conexión, caerá a fallback
      }
    }
    if (!res.ok) {
      // Fallback de compatibilidad: si /facturas no existe (404), usar flujo legacy por item
      if (res.status === 404) {
        __facturasEnabled = false;
        for (const item of facturaActual) {
          const r = await fetch('/movimientos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              productoId: item.id,
              tipo: 'venta',
              cantidad: item.cantidad,
              fecha: new Date().toISOString().slice(0, 10)
            })
          });
          if (!r.ok) {
            const err = await r.json().catch(() => ({}));
            mostrarAlerta(err.error || 'Error al registrar venta', 'error');
            return;
          }
        }
        // Resumen local si se usó fallback
        const ahora = new Date();
        const fechaLocal = ahora.toLocaleString('es-PE');
        const lineasFb = [
          `FACTURA (fallback sin almacenamiento)` ,
          `Fecha/hora: ${fechaLocal}`,
          `Cédula: ${cedulaCliente.value.trim() || '-'}`,
          `Método de pago: ${metodoPago}`,
          '',
          'PRODUCTOS:'
        ];
        facturaActual.forEach(d => lineasFb.push(`${d.nombre} x${d.cantidad} ${d.unidad} @ ${formatoMoneda(d.precio)} = ${formatoMoneda(d.total)}`));
        const totalFb = facturaActual.reduce((s, it) => s + it.total, 0);
        lineasFb.push('', `TOTAL: ${formatoMoneda(totalFb)}`);
        alert(lineasFb.join('\n'));

        limpiarFactura();
        cargarProductos(inputBusqueda.value.trim());
        recargarVentasRecientes();
        cargarMovimientos();
        actualizarKPIs();
        cargarVentasResumen();
        cargarKPIsDelDia();
        mostrarAlerta('Factura procesada (modo compatibilidad)');
        return;
      }
      const error = await res.json().catch(() => ({}));
      mostrarAlerta(error.error || 'Error al crear la factura', 'error');
      return;
    }
    const data = await res.json();
    const f = data.factura;
    const detalle = data.items || [];

    // Mostrar resumen de factura (limpio y legible)
    const lineas = [
      `FACTURA ${f.numero}`,
      `Fecha/hora: ${f.fecha_hora}`,
      `Cédula: ${f.cliente_cedula || '-'}`,
      `Método de pago: ${f.metodo_pago}`,
      '',
      'PRODUCTOS:'
    ];
    detalle.forEach(d => lineas.push(`${d.nombre} x${d.cantidad} ${d.unidad} @ ${formatoMoneda(d.precio_unitario)} = ${formatoMoneda(d.total)}`));
    lineas.push('', `SUBTOTAL: ${formatoMoneda(f.subtotal)}`, `TOTAL: ${formatoMoneda(f.total)}`);
    alert(lineas.join('\n'));

    // Limpiar y refrescar
    limpiarFactura();
    cargarProductos(inputBusqueda.value.trim());
    recargarVentasRecientes();
    cargarMovimientos();
    actualizarKPIs();
    cargarVentasResumen();
    cargarKPIsDelDia();
    mostrarAlerta('Factura procesada exitosamente');
  } catch (error) {
    console.error('Error al procesar factura:', error);
    mostrarAlerta('Error al procesar la factura', 'error');
  }
}

// Generar número de factura único
function generarNumeroFactura() {
  const ahora = new Date();
  const timestamp = ahora.getTime();
  const random = Math.floor(Math.random() * 1000);
  return `F${timestamp.toString().slice(-8)}${random.toString().padStart(3, '0')}`;
}

// Event listeners para facturación
if (montoRecibido) {
  montoRecibido.addEventListener('input', actualizarCambio);
}

if (btnLimpiarFactura) {
  btnLimpiarFactura.addEventListener('click', limpiarFactura);
}


// Cargar productos disponibles al inicializar
cargarProductosDisponibles();

// Inicializar factura cuando se carga la vista de ventas
function inicializarVistaVentas() {
  console.log('Inicializando vista de ventas...');
  
  // Cargar elementos del DOM inmediatamente
  buscarProductoFactura = document.querySelector('#buscarProductoFactura');
  resultadosBusqueda = document.querySelector('#resultadosBusqueda');
  productoSeleccionado = document.querySelector('#productoSeleccionado');
  nombreProducto = document.querySelector('#nombreProducto');
  precioProducto = document.querySelector('#precioProducto');
  stockProducto = document.querySelector('#stockProducto');
  cantidadFactura = document.querySelector('#cantidadFactura');
  btnAgregarProducto = document.querySelector('#btnAgregarProducto');
  facturaBody = document.querySelector('#facturaBody');
  facturaVacia = document.querySelector('#facturaVacia');
  totalesFactura = document.querySelector('#totalesFactura');
  subtotalFactura = document.querySelector('#subtotalFactura');
  totalFactura = document.querySelector('#totalFactura');
  numeroFactura = document.querySelector('#numeroFactura');
  fechaFactura = document.querySelector('#fechaFactura');
  cedulaCliente = document.querySelector('#cedulaCliente');
  opcionesPago = document.querySelector('#opcionesPago');
  montoRecibido = document.querySelector('#montoRecibido');
  cambioMonto = document.querySelector('#cambioMonto');
  pagoEfectivo = document.querySelector('#pagoEfectivo');
  btnLimpiarFactura = document.querySelector('#btnLimpiarFactura');
  btnProcesarFactura = document.querySelector('#btnProcesarFactura');
  tablaVentasBody = document.querySelector('#tablaVentas tbody');
  
  console.log('Elementos cargados:', {
    buscarProductoFactura: !!buscarProductoFactura,
    resultadosBusqueda: !!resultadosBusqueda,
    btnAgregarProducto: !!btnAgregarProducto,
    btnProcesarFactura: !!btnProcesarFactura
  });
  
  // Inicializar factura
  if (numeroFactura && fechaFactura) {
    inicializarFactura();
  }
  // Refrescar catálogo para sugerencias cada vez que se abre esta vista
  cargarProductosDisponibles();
  
  // Configurar búsqueda
  if (buscarProductoFactura && resultadosBusqueda) {
    console.log('Configurando búsqueda...');
    
    buscarProductoFactura.addEventListener('input', (e) => {
      const query = e.target.value.trim().toLowerCase();
      console.log('Buscando:', query);
      
      if (query.length < 1) {
        resultadosBusqueda.hidden = true;
        if (productoSeleccionado) productoSeleccionado.hidden = true;
        return;
      }
      
      // Priorizar comienza con, luego incluye
      const lista = productosDisponibles.filter(p => p.cantidad > 0);
      const empieza = lista.filter(p => p.nombre.toLowerCase().startsWith(query));
      const contiene = lista.filter(p => !p.nombre.toLowerCase().startsWith(query) && p.nombre.toLowerCase().includes(query));
      const resultados = empieza.concat(contiene).slice(0, 8);
      
      console.log('Resultados encontrados:', resultados.length);
      
      if (resultados.length === 0) {
        resultadosBusqueda.hidden = true;
        return;
      }
      
      resultadosBusqueda.innerHTML = resultados.map(p => {
        const nombre = p.nombre;
        const idx = nombre.toLowerCase().indexOf(query);
        const marcado = idx >= 0 ? `${nombre.slice(0, idx)}<mark>${nombre.slice(idx, idx + query.length)}</mark>${nombre.slice(idx + query.length)}` : nombre;
        return `
        <div class="resultado-item" data-producto-id="${p.id}">
          <div class="resultado-info">
            <div class="resultado-nombre">${marcado}</div>
            <div class="resultado-details">${p.cantidad} ${p.unidad} disponibles</div>
          </div>
          <div class="resultado-precio">${formatoMoneda(p.precio)}</div>
        </div>
      `;
      }).join('');
      
      resultadosBusqueda.hidden = false;
    });
    
    // Manejar clic en resultados
    resultadosBusqueda.addEventListener('click', (e) => {
      const item = e.target.closest('.resultado-item');
      if (item) {
        const productoId = parseInt(item.dataset.productoId);
        const producto = productosDisponibles.find(p => p.id === productoId);
        if (producto) {
          console.log('Producto seleccionado:', producto.nombre);
          
          // Mostrar producto seleccionado
          if (nombreProducto) nombreProducto.textContent = producto.nombre;
          if (precioProducto) precioProducto.textContent = formatoMoneda(producto.precio);
          if (stockProducto) stockProducto.textContent = `${producto.cantidad} ${producto.unidad} disponibles`;
          if (cantidadFactura) {
            cantidadFactura.value = 1;
            cantidadFactura.max = producto.cantidad;
          }
          if (productoSeleccionado) productoSeleccionado.hidden = false;
          
          productoActual = producto;
          resultadosBusqueda.hidden = true;
          buscarProductoFactura.value = '';
        }
      }
    });

    // Ocultar resultados al hacer clic fuera
    document.addEventListener('click', (ev) => {
      if (!resultadosBusqueda.contains(ev.target) && ev.target !== buscarProductoFactura) {
        resultadosBusqueda.hidden = true;
      }
    });
  }
  
  // Configurar botón de agregar
  if (btnAgregarProducto) {
    console.log('Configurando botón agregar...');
    btnAgregarProducto.addEventListener('click', () => {
      console.log('Botón agregar clickeado');
      if (!productoActual) {
        mostrarAlerta('Selecciona un producto primero', 'error');
        return;
      }
      
      const cantidad = parseInt(cantidadFactura ? cantidadFactura.value : 1);
      if (cantidad < 1 || cantidad > productoActual.cantidad) {
        mostrarAlerta('Cantidad inválida', 'error');
        return;
      }
      
      // Verificar si ya existe
      const existente = facturaActual.find(item => item.id === productoActual.id);
      if (existente) {
        mostrarAlerta('Este producto ya está en la factura', 'error');
        return;
      }
      
      // Agregar a la factura
      facturaActual.push({
        id: productoActual.id,
        nombre: productoActual.nombre,
        precio: productoActual.precio,
        unidad: productoActual.unidad,
        cantidad: cantidad,
        total: productoActual.precio * cantidad,
        stockDisponible: productoActual.cantidad
      });
      
      console.log('Producto agregado a factura:', productoActual.nombre);
      actualizarFactura();
      
      // Limpiar
      productoActual = null;
      if (productoSeleccionado) productoSeleccionado.hidden = true;
      if (buscarProductoFactura) buscarProductoFactura.value = '';
      if (cantidadFactura) cantidadFactura.value = 1;
    });
  }
  
  // Configurar botones
  if (btnProcesarFactura) {
    console.log('Configurando botón procesar...');
    btnProcesarFactura.addEventListener('click', procesarFactura);
  }
  
  if (btnLimpiarFactura) {
    console.log('Configurando botón limpiar...');
    btnLimpiarFactura.addEventListener('click', limpiarFactura);
  }
  
  if (montoRecibido) {
    montoRecibido.addEventListener('input', actualizarCambio);
  }
}

// KPIs del día (facturas y ventas)
async function cargarKPIsDelDia() {
  const kFacturas = document.querySelector('#kpiFacturasHoy');
  const kVentas = document.querySelector('#kpiVentasHoy');
  if (!kFacturas && !kVentas) return;
  try {
    const hoy = new Date().toISOString().slice(0,10);
    if (__facturasEnabled === false) {
      const resV = await fetch('/ventas');
      const ventas = await resV.json();
      const ventasHoy = ventas.filter(v => String(v.fecha).slice(0,10) === hoy);
      if (kFacturas) kFacturas.textContent = ventasHoy.length;
      if (kVentas) kVentas.textContent = formatoMoneda(ventasHoy.reduce((s, v) => s + Number(v.total || 0), 0));
      return;
    }
    const res = await fetch(`/facturas?from=${hoy}&to=${hoy}`);
    if (res.status === 404) {
      __facturasEnabled = false;
      return cargarKPIsDelDia();
    }
    const facturas = await res.json();
    const totalFacturas = facturas.length;
    const totalVentas = facturas.reduce((acc, f) => acc + Number(f.total || 0), 0);
    if (kFacturas) kFacturas.textContent = totalFacturas;
    if (kVentas) kVentas.textContent = formatoMoneda(totalVentas);
  } catch (_) {
    if (kFacturas) kFacturas.textContent = '0';
    if (kVentas) kVentas.textContent = formatoMoneda(0);
  }
}

// Detección inicial de soporte de facturas en backend (best-effort)
(async function detectarSoporteFacturas(){
  try {
    const res = await fetch('/facturas');
    __facturasEnabled = res.ok;
  } catch (_) {
    __facturasEnabled = false;
  }
})();
