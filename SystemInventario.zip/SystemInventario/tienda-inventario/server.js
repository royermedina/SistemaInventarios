const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");

// Crear app y base de datos
const app = express();
const db = new Database("database.db");
// Asegurar integridad referencial
try { db.pragma('foreign_keys = ON'); } catch (_) {}

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

// Crear tablas si no existen
db.prepare(`
  CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT,
    cantidad INTEGER,
    precio REAL
  )
`).run();

// Migración: agregar columna unidad si no existe
try {
  const cols = db.prepare("PRAGMA table_info(productos)").all();
  const tieneUnidad = cols.some(c => c.name === 'unidad');
  if (!tieneUnidad) {
    db.prepare("ALTER TABLE productos ADD COLUMN unidad TEXT DEFAULT 'unidad'").run();
  }
} catch (e) {
  console.error('Error migración unidad:', e.message);
}

// Tabla de movimientos de inventario
db.prepare(`
  CREATE TABLE IF NOT EXISTS movimientos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL,
    tipo TEXT NOT NULL, -- 'compra' | 'venta' | 'ajuste'
    cantidad REAL NOT NULL,
    unidad TEXT NOT NULL,
    fecha TEXT NOT NULL,
    precio_unitario REAL,
    nota TEXT,
    saldo REAL NOT NULL,
    FOREIGN KEY(producto_id) REFERENCES productos(id)
  )
`).run();

// Tabla de ventas (histórico de ventas simples)
db.prepare(`
  CREATE TABLE IF NOT EXISTS ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    fecha TEXT,
    producto_id INTEGER,
    cantidad INTEGER,
    total REAL,
    FOREIGN KEY (producto_id) REFERENCES productos(id)
  )
`).run();

// Facturación estructurada: facturas y sus items
db.prepare(`
  CREATE TABLE IF NOT EXISTS facturas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT NOT NULL,
    fecha_hora TEXT NOT NULL,
    cliente_cedula TEXT,
    metodo_pago TEXT NOT NULL,
    subtotal REAL NOT NULL,
    total REAL NOT NULL
  )
`).run();

db.prepare(`
  CREATE TABLE IF NOT EXISTS factura_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    factura_id INTEGER NOT NULL,
    producto_id INTEGER NOT NULL,
    nombre TEXT NOT NULL,
    unidad TEXT NOT NULL,
    precio_unitario REAL NOT NULL,
    cantidad INTEGER NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY(factura_id) REFERENCES facturas(id),
    FOREIGN KEY(producto_id) REFERENCES productos(id)
  )
`).run();

// Obtener productos (con búsqueda opcional por nombre)
app.get("/productos", (req, res) => {
  const { search, sort, order, unit } = req.query;
  const clauses = [];
  const params = [];
  if (search && String(search).trim() !== "") {
    clauses.push("nombre LIKE ?");
    params.push(`%${String(search).trim()}%`);
  }
  if (unit && String(unit) !== 'all') {
    if (unit === 'weight') {
      clauses.push("unidad IN ('kg','lb')");
    } else {
      clauses.push("unidad = ?");
      params.push(String(unit));
    }
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const allowedSort = ['id','nombre'];
  const s = allowedSort.includes(String(sort)) ? String(sort) : 'id';
  const o = ['asc','desc'].includes(String(order)) ? String(order) : 'desc';
  const sql = `SELECT * FROM productos ${where} ORDER BY ${s} ${o.toUpperCase()}`;
  const productos = db.prepare(sql).all(...params);
  res.json(productos);
});

// Agregar producto
app.post("/productos", (req, res) => {
  let { nombre, cantidad, precio, unidad } = req.body;
  nombre = typeof nombre === "string" ? nombre.trim() : "";
  const errores = [];
  if (!nombre) errores.push("El nombre es requerido");
  if (!Number.isInteger(cantidad) || cantidad < 0) errores.push("La cantidad debe ser un entero >= 0");
  if (typeof precio !== "number" || isNaN(precio) || precio < 0) errores.push("El precio debe ser un número >= 0");
  const UNIDADES = ["unidad", "kg", "lb"];
  if (typeof unidad !== "string" || !UNIDADES.includes(unidad)) errores.push("Unidad inválida (unidad|kg|lb)");

  // Validación de nombre duplicado (case-insensitive)
  const existente = db.prepare("SELECT id FROM productos WHERE LOWER(nombre) = LOWER(?)").get(nombre);
  if (existente) errores.push("Ya existe un producto con ese nombre");

  if (errores.length) {
    return res.status(400).json({ errores });
  }

  const info = db.prepare("INSERT INTO productos (nombre, cantidad, precio, unidad) VALUES (?, ?, ?, ?)")
    .run(nombre, cantidad, precio, unidad);
  const creado = db.prepare("SELECT * FROM productos WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json(creado);
});

// Actualizar producto (nombre, cantidad, precio)
app.put("/productos/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "ID inválido" });

  // Permitir updates parciales
  let { nombre, cantidad, precio, unidad } = req.body;
  const setClauses = [];
  const params = [];

  if (typeof nombre === "string") {
    nombre = nombre.trim();
    if (!nombre) return res.status(400).json({ error: "El nombre no puede estar vacío" });
    // Evitar duplicados
    const duplicado = db.prepare("SELECT id FROM productos WHERE LOWER(nombre) = LOWER(?) AND id <> ?").get(nombre, id);
    if (duplicado) return res.status(400).json({ error: "Ya existe un producto con ese nombre" });
    setClauses.push("nombre = ?");
    params.push(nombre);
  }
  if (cantidad !== undefined) {
    if (!Number.isInteger(cantidad)) return res.status(400).json({ error: "La cantidad debe ser un entero" });
    setClauses.push("cantidad = ?");
    params.push(cantidad);
  }
  if (precio !== undefined) {
    if (typeof precio !== "number" || isNaN(precio)) return res.status(400).json({ error: "El precio debe ser numérico" });
    setClauses.push("precio = ?");
    params.push(precio);
  }
  if (unidad !== undefined) {
    const UNIDADES = ["unidad", "kg", "lb"];
    if (typeof unidad !== "string" || !UNIDADES.includes(unidad)) return res.status(400).json({ error: "Unidad inválida (unidad|kg|lb)" });
    setClauses.push("unidad = ?");
    params.push(unidad);
  }

  if (setClauses.length === 0) return res.status(400).json({ error: "No hay campos para actualizar" });

  const sentencia = `UPDATE productos SET ${setClauses.join(", ")} WHERE id = ?`;
  const result = db.prepare(sentencia).run(...params, id);
  if (result.changes === 0) return res.status(404).json({ error: "Producto no encontrado" });
  const actualizado = db.prepare("SELECT * FROM productos WHERE id = ?").get(id);
  res.json(actualizado);
});

// Eliminar producto
app.delete("/productos/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "ID inválido" });
  try {
    const tx = db.transaction((productoId) => {
      db.prepare("DELETE FROM ventas WHERE producto_id = ?").run(productoId);
      db.prepare("DELETE FROM movimientos WHERE producto_id = ?").run(productoId);
      const result = db.prepare("DELETE FROM productos WHERE id = ?").run(productoId);
      return result;
    });
    const result = tx(id);
    if (result.changes === 0) return res.status(404).json({ error: "Producto no encontrado" });
    res.json({ mensaje: "Producto eliminado" });
  } catch (e) {
    console.error('Error al eliminar producto:', e);
    res.status(500).json({ error: 'No se pudo eliminar el producto' });
  }
});

// Registrar movimiento de inventario (compra/venta/ajuste)
app.post("/movimientos", (req, res) => {
  const { productoId, tipo, cantidad, fecha, precioUnitario, nota, nuevaCantidad } = req.body;
  const id = Number(productoId);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Producto inválido" });
  const producto = db.prepare("SELECT * FROM productos WHERE id = ?").get(id);
  if (!producto) return res.status(404).json({ error: "Producto no encontrado" });
  const UNIDADES = ["unidad", "kg", "lb"];
  if (!UNIDADES.includes(producto.unidad)) return res.status(400).json({ error: "Unidad del producto inválida" });
  const tipos = ["compra", "venta", "ajuste"];
  if (!tipos.includes(tipo)) return res.status(400).json({ error: "Tipo inválido (compra|venta|ajuste)" });

  const qty = Number(cantidad);
  if (!(qty > 0) && tipo !== 'ajuste') return res.status(400).json({ error: "Cantidad debe ser > 0" });

  let saldo;
  if (tipo === 'compra') {
    saldo = Number(producto.cantidad) + qty;
  } else if (tipo === 'venta') {
    saldo = Number(producto.cantidad) - qty;
    if (saldo < 0) return res.status(400).json({ error: "No hay suficiente inventario" });
  } else {
    const target = Number(nuevaCantidad);
    if (!Number.isFinite(target) || target < 0) return res.status(400).json({ error: "nuevaCantidad inválida" });
    saldo = target;
  }

  // Actualizar producto
  db.prepare("UPDATE productos SET cantidad = ? WHERE id = ?").run(Math.round(saldo), id);

  const fechaISO = typeof fecha === 'string' && fecha.trim() ? fecha : new Date().toISOString().slice(0, 10);
  const info = db.prepare(`
    INSERT INTO movimientos (producto_id, tipo, cantidad, unidad, fecha, precio_unitario, nota, saldo)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, tipo, qty, producto.unidad, fechaISO, precioUnitario ?? null, nota ?? null, Math.round(saldo));
  // Si es una venta, también registrar en ventas para cumplir API solicitada
  if (tipo === 'venta') {
    const total = Number.isFinite(precioUnitario) ? Number(precioUnitario) * qty : Number(producto.precio || 0) * qty;
    db.prepare(`
      INSERT INTO ventas (fecha, producto_id, cantidad, total)
      VALUES (?, ?, ?, ?)
    `).run(fechaISO, id, Math.round(qty), total);
  }
  const creado = db.prepare("SELECT m.*, p.nombre FROM movimientos m JOIN productos p ON p.id = m.producto_id WHERE m.id = ?").get(info.lastInsertRowid);
  res.status(201).json(creado);
});

// Listar movimientos con filtros (?from=YYYY-MM-DD&to=YYYY-MM-DD&productoId=)
app.get("/movimientos", (req, res) => {
  const { from, to, productoId } = req.query;
  const clauses = [];
  const params = [];
  if (from) { clauses.push("date(fecha) >= date(?)"); params.push(String(from)); }
  if (to) { clauses.push("date(fecha) <= date(?)"); params.push(String(to)); }
  if (productoId) { clauses.push("producto_id = ?"); params.push(Number(productoId)); }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const sql = `SELECT m.*, p.nombre FROM movimientos m JOIN productos p ON p.id = m.producto_id ${where} ORDER BY datetime(fecha) DESC, m.id DESC`;
  const rows = db.prepare(sql).all(...params);
  res.json(rows);
});

// Listar ventas
app.get("/ventas", (req, res) => {
  const rows = db.prepare(`
    SELECT v.*, p.nombre FROM ventas v
    JOIN productos p ON p.id = v.producto_id
    ORDER BY fecha DESC, v.id DESC
  `).all();
  res.json(rows);
});

// Listar facturas (opcionalmente por rango de fecha)
app.get("/facturas", (req, res) => {
  const { from, to } = req.query;
  const clauses = [];
  const params = [];
  if (from) { clauses.push("date(fecha_hora) >= date(?)"); params.push(String(from)); }
  if (to) { clauses.push("date(fecha_hora) <= date(?)"); params.push(String(to)); }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const sql = `SELECT f.*, (SELECT COUNT(*) FROM factura_items fi WHERE fi.factura_id = f.id) AS items_count FROM facturas f ${where} ORDER BY datetime(fecha_hora) DESC, id DESC`;
  const rows = db.prepare(sql).all(...params);
  res.json(rows);
});

// Detalle de items de una factura
app.get("/facturas/:id/items", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "ID inválido" });
  const items = db.prepare(`SELECT * FROM factura_items WHERE factura_id = ? ORDER BY id`).all(id);
  res.json(items);
});

// Crear una factura con items y descontar inventario (incluye movimientos y ventas legacy)
app.post("/facturas", (req, res) => {
  const { clienteCedula, metodoPago, items } = req.body;
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "La factura requiere items" });
  }
  const metodo = String(metodoPago || 'efectivo');
  const ahora = new Date();
  // Fecha/hora local con segundos (YYYY-MM-DD HH:mm:ss)
  const fechaHora = new Date(ahora.getTime() - ahora.getTimezoneOffset()*60000).toISOString().replace('T',' ').slice(0,19);
  const numero = `F${ahora.getFullYear()}${String(ahora.getMonth()+1).padStart(2,'0')}${String(ahora.getDate()).padStart(2,'0')}-${String(ahora.getHours()).padStart(2,'0')}${String(ahora.getMinutes()).padStart(2,'0')}${String(ahora.getSeconds()).padStart(2,'0')}-${Math.floor(Math.random()*1000).toString().padStart(3,'0')}`;

  try {
    const tx = db.transaction((payloadItems) => {
      // Validar productos y calcular totales
      let subtotal = 0;
      const enriched = payloadItems.map((it) => {
        const id = Number(it.productoId);
        const cantidad = Number(it.cantidad);
        if (!Number.isInteger(id) || !(cantidad > 0)) {
          throw new Error("Item inválido");
        }
        const producto = db.prepare("SELECT * FROM productos WHERE id = ?").get(id);
        if (!producto) throw new Error("Producto no encontrado");
        if (producto.cantidad < cantidad) throw new Error(`Inventario insuficiente para ${producto.nombre}`);
        const precioUnitario = Number.isFinite(it.precioUnitario) ? Number(it.precioUnitario) : Number(producto.precio || 0);
        const total = precioUnitario * cantidad;
        subtotal += total;
        return { id, cantidad, producto, precioUnitario, total };
      });

      // Crear factura
      const info = db.prepare(`
        INSERT INTO facturas (numero, fecha_hora, cliente_cedula, metodo_pago, subtotal, total)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(numero, fechaHora, (clienteCedula || null), metodo, subtotal, subtotal);
      const facturaId = info.lastInsertRowid;

      // Procesar items: descontar inventario, registrar item, movimiento y venta legacy
      enriched.forEach(({ id, cantidad, producto, precioUnitario, total }) => {
        const nuevoSaldo = Number(producto.cantidad) - cantidad;
        if (nuevoSaldo < 0) throw new Error("No hay suficiente inventario");
        db.prepare("UPDATE productos SET cantidad = ? WHERE id = ?").run(Math.round(nuevoSaldo), id);
        db.prepare(`
          INSERT INTO factura_items (factura_id, producto_id, nombre, unidad, precio_unitario, cantidad, total)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(facturaId, id, producto.nombre, producto.unidad, precioUnitario, Math.round(cantidad), total);
        // Movimiento
        db.prepare(`
          INSERT INTO movimientos (producto_id, tipo, cantidad, unidad, fecha, precio_unitario, nota, saldo)
          VALUES (?, 'venta', ?, ?, ?, ?, ?, ?)
        `).run(id, cantidad, producto.unidad, fechaHora.slice(0,10), precioUnitario, `Factura ${numero}`, Math.round(nuevoSaldo));
        // Legacy ventas para compatibilidad
        db.prepare(`
          INSERT INTO ventas (fecha, producto_id, cantidad, total)
          VALUES (?, ?, ?, ?)
        `).run(fechaHora, id, Math.round(cantidad), total);
      });

      return facturaId;
    });

    const facturaId = tx(items);
    const factura = db.prepare("SELECT * FROM facturas WHERE id = ?").get(facturaId);
    const detalle = db.prepare("SELECT * FROM factura_items WHERE factura_id = ?").all(facturaId);
    res.status(201).json({ factura, items: detalle });
  } catch (e) {
    console.error('Error creando factura:', e);
    return res.status(400).json({ error: e.message || 'No se pudo crear la factura' });
  }
});

// Registrar venta (y decrementar inventario)
app.post("/ventas", (req, res) => {
  const { productoId, cantidad, fecha, precioUnitario } = req.body;
  const id = Number(productoId);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "Producto inválido" });
  const qty = Number(cantidad);
  if (!(qty > 0)) return res.status(400).json({ error: "Cantidad debe ser > 0" });
  const producto = db.prepare("SELECT * FROM productos WHERE id = ?").get(id);
  if (!producto) return res.status(404).json({ error: "Producto no encontrado" });
  const nuevoSaldo = Number(producto.cantidad) - qty;
  if (nuevoSaldo < 0) return res.status(400).json({ error: "No hay suficiente inventario" });
  // Actualizar inventario
  db.prepare("UPDATE productos SET cantidad = ? WHERE id = ?").run(Math.round(nuevoSaldo), id);
  // Fecha
  const fechaISO = typeof fecha === 'string' && fecha.trim() ? fecha : new Date().toISOString().slice(0, 10);
  // Total (usa precioUnitario si viene, si no precio del producto)
  const unit = Number.isFinite(precioUnitario) ? Number(precioUnitario) : Number(producto.precio || 0);
  const total = unit * qty;
  const info = db.prepare(`
    INSERT INTO ventas (fecha, producto_id, cantidad, total)
    VALUES (?, ?, ?, ?)
  `).run(fechaISO, id, Math.round(qty), total);
  // También crear un movimiento de tipo venta para historial de inventario
  db.prepare(`
    INSERT INTO movimientos (producto_id, tipo, cantidad, unidad, fecha, precio_unitario, nota, saldo)
    VALUES (?, 'venta', ?, ?, ?, ?, ?, ?)
  `).run(id, qty, producto.unidad, fechaISO, unit, null, Math.round(nuevoSaldo));
  const creado = db.prepare("SELECT v.*, p.nombre FROM ventas v JOIN productos p ON p.id = v.producto_id WHERE v.id = ?").get(info.lastInsertRowid);
  res.status(201).json(creado);
});

// Iniciar servidor
app.listen(3000, () => console.log("Servidor corriendo en http://localhost:3000"));
